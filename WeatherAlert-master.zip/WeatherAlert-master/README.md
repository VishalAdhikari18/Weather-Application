# Weather Application (unfinished)
- This application is one of my first bigger projects in C#
- Photographer (user) can pick settings their choice and UI will show map with current conditions
- For example if I live in Brno and I want to take picture with morning nature in rain, I can set settings like   
humidity, time of day, place (around Brno) etc. UI will notify me when and where I can shoot these pictures.
